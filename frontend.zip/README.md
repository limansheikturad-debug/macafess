# MACAFESS Frontend
This is the React + Tailwind frontend for MACAFESS Trading Hub Academy.
import React, { useState } from "react";
import axios from "axios";

function App() {
  const [form, setForm] = useState({ name: "", email: "", message: "" });

  const handleChange = (e) => {
    setForm({ ...form, [e.target.name]: e.target.value });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      await axios.post("https://macafess-api.onrender.com/contact", form);
      alert("✅ Message sent! Please check your email.");
    } catch (err) {
      alert("❌ Error sending message.");
    }
  };

  return (
    <div className="min-h-screen bg-gray-100 flex flex-col items-center justify-center">
      <h1 className="text-3xl font-bold text-blue-600 mb-6">MACAFESS Trading Hub</h1>
      <form onSubmit={handleSubmit} className="bg-white p-6 rounded-xl shadow-lg w-96">
        <input type="text" name="name" placeholder="Your Name" onChange={handleChange}
          className="w-full border p-2 mb-3 rounded" required />
        <input type="email" name="email" placeholder="Your Email" onChange={handleChange}
          className="w-full border p-2 mb-3 rounded" required />
        <textarea name="message" placeholder="Your Message" onChange={handleChange}
          className="w-full border p-2 mb-3 rounded" required />
        <button type="submit" className="w-full bg-blue-600 text-white p-2 rounded">Send</button>
      </form>
    </div>
  );
}

export default App;
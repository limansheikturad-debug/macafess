const express = require("express");
const nodemailer = require("nodemailer");
const router = express.Router();

router.post("/", async (req, res) => {
  const { name, email, message } = req.body;

  try {
    const transporter = nodemailer.createTransport({
      service: "gmail",
      auth: {
        user: process.env.EMAIL_USER,
        pass: process.env.EMAIL_PASS
      }
    });

    // Send email to MACAFESS support
    await transporter.sendMail({
      from: email,
      to: process.env.RECEIVE_EMAIL,
      subject: `📩 New Message from ${name}`,
      text: message
    });

    // Auto-reply email to client
    await transporter.sendMail({
      from: `"MACAFESS Support" <${process.env.EMAIL_USER}>`,
      to: email,
      subject: "✅ We’ve received your message – MACAFESS Support",
      html: `
        <div style="max-width:600px; margin:auto; font-family:Arial,sans-serif; border:1px solid #eaeaea; border-radius:10px; overflow:hidden;">
          <div style="background:#0d6efd; padding:20px; text-align:center; color:white;">
            <h1 style="margin:0;">MACAFESS</h1>
            <p style="margin:0;">Trading Hub Academy</p>
          </div>
          <div style="padding:20px; color:#333;">
            <p>Hello <strong>${name}</strong>,</p>
            <p>Thank you for contacting <strong>MACAFESS Trading Hub Academy</strong>. 
            We’ve received your message and our support team will reach out within 24 hours.</p>
            <p>Meanwhile, you can also reach us directly if needed:</p>
            <ul style="list-style:none; padding:0;">
              <li>📧 Email: <a href="mailto:limansheikturad@gmail.com">limansheikturad@gmail.com</a></li>
              <li>🌍 Website: <a href="https://www.macafess.com">www.macafess.com</a></li>
              <li>📞 Support: +234 806 695 5923</li>
            </ul>
            <p>We look forward to assisting you.</p>
          </div>
          <div style="background:#f4f4f4; padding:15px; text-align:center; font-size:12px; color:#777;">
            © ${new Date().getFullYear()} MACAFESS Trading Hub Academy. All rights reserved.
          </div>
        </div>
      `
    });

    res.json({ success: true });
  } catch (err) {
    console.error(err);
    res.status(500).json({ success: false, error: "Failed to send email" });
  }
});

module.exports = router;